﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskScheduler
{
    using System;
    using System.Collections.Generic;

    public class COM : IComparable<COM>
    {
        private static int comIdCounter = 0;
        public int Bandwidth { get; }
        public int ConnectCost { get; }
        public int Id { get; }
        private List<Hardware> Line;

        public COM(int bandwidth, int cost)
        {
            Bandwidth = bandwidth;
            ConnectCost = cost;
            Id = comIdCounter++;
            Line = new List<Hardware>();
        }

        public void AddHardware(Hardware h)
        {
            Line.Add(h);
        }

        public int GetSize() => Line.Count;

        public void PrintCOM(System.IO.TextWriter output, int maxHwId)
        {
            output.Write($"CHAN{Id} {Bandwidth} {ConnectCost} ");
            for (int i = 0; i < maxHwId; i++)
            {
                output.Write($"{IsConnected(i)} ");
            }
            output.WriteLine();
        }

        private bool IsConnected(int id)
        {
            foreach (var h in Line)
                if (h.Id == id) return true;
            return false;
        }

        public int CompareTo(COM other) => Id.CompareTo(other.Id);
    }

}
