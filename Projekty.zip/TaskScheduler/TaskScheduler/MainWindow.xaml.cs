﻿using System;
using System.Windows;

namespace TaskScheduler
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OnGenerateClick(object sender, RoutedEventArgs e)
        {
            try
            {
                int tasks = int.Parse(TaskCountBox.Text);
                int hc = int.Parse(HcCountBox.Text);
                int pu = int.Parse(PuCountBox.Text);
                int coms = int.Parse(ComCountBox.Text);
                bool withCost = WithCostBox.IsChecked == true;

                Program.Make(tasks, hc, pu, coms, withCost, true);
                MessageBox.Show("Zapisano tasks.dat");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Błąd: " + ex.Message);
            }
        }
    }
}
