﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace TaskScheduler
{
    public class Program
    {
        private static int SCALE = 400;
        private static int hwIdCounter = 0;
        private static int comIdCounter = 0;
        private static List<Hardware> Hardwares = new List<Hardware>();
        private static List<COM> Channels = new List<COM>();
        
        private static Graph TaskGraph = new Graph();
        private static Times times = new Times(TaskGraph,Hardwares);

        public static void Make(int tasksAmount, int hcAmount, int puAmount, int chAmount, bool withCost, bool toScreen)
        {
            var outputFile = new StreamWriter("tasks.dat");
            Graph graph = new Graph();
            graph.CreateVertices(tasksAmount);
            // You need to implement CreateTasksGraph() in C# if needed.

            var HWList = new List<Hardware>();
            for (int i = 0; i < hcAmount; i++)
                HWList.Add(new Hardware(new Random().Next(1, 6), HardwareType.HC));
            for (int i = 0; i < puAmount; i++)
                HWList.Add(new Hardware(new Random().Next(1, 6), HardwareType.PE));

            var t = new Times(graph, HWList);

            if (toScreen)
                PrintProc(HWList, Console.Out);

            PrintProc(HWList, outputFile);
            t.Show(outputFile);

            var coms = new List<COM>();
            for (int i = 0; i < chAmount; i++)
            {
                int bd = (new Random().Next(1, 10)) * 10;
                int cost = (new Random().Next(1, 10)) * 5;
                COM c = new COM(bd, cost);

                foreach (var hw in HWList)
                    if (new Random().Next(0, 2) == 0)
                        c.AddHardware(hw);

                while (c.GetSize() < 3)
                    c.AddHardware(HWList[new Random().Next(HWList.Count)]);

                coms.Add(c);
            }

            PrintCOMS(coms, outputFile, hwIdCounter);
            outputFile.Close();

            Console.WriteLine("Zapisano do pliku tasks.dat");
        }

        public static int LoadGraphFromFile(string filename)
        {
            if (!File.Exists(filename))
                return -1;

            int section = -1;
            List<List<int>> timesMatrix = new List<List<int>>();
            List<List<int>> costsMatrix = new List<List<int>>();

            try
            {
                foreach (var lineRaw in File.ReadLines(filename))
                {
                    string line = lineRaw.Trim();
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    if (line.Contains("@tasks"))
                    {
                        section = 0;
                    }
                    else if (line.Contains("@proc"))
                    {
                        section = 1;
                    }
                    else if (line.Contains("@times"))
                    {
                        section = 2;
                    }
                    else if (line.Contains("@cost"))
                    {
                        section = 3;
                    }
                    else if (line.Contains("@comm"))
                    {
                        section = 4;
                    }
                    else
                    {
                        switch (section)
                        {
                            case 0: // @tasks section - wczytanie krawędzi grafu
                                {
                                    // Format: c Tnum tasks to c weight c ...
                                    // Przykład: (tutaj przyjmuję: c - znak, int - liczba)
                                    var parts = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                                    if (parts.Length < 3)
                                        break;

                                    // Parsowanie lini: format niestandardowy, trzeba dopasować do własnego formatu
                                    // Załóżmy: c Tnum tasks to c weight c (powtarzające się)
                                    // Uproszczona wersja:
                                    int index = 0;
                                    while (index < parts.Length)
                                    {
                                        if (char.TryParse(parts[index], out char c) && c == 'c')
                                        {
                                            if (index + 2 >= parts.Length) break;
                                            int Tnum = int.Parse(parts[index + 1]);
                                            int tasks = int.Parse(parts[index + 2]);
                                            index += 3;
                                            while (index + 3 <= parts.Length)
                                            {
                                                if (int.TryParse(parts[index], out int to) && parts[index + 1] == "c" &&
                                                    int.TryParse(parts[index + 2], out int weight) && parts[index + 3] == "c")
                                                {
                                                    if (weight == 0) weight = 1;
                                                    TaskGraph.AddEdge(Tnum, to, weight);
                                                    index += 4;
                                                }
                                                else
                                                {
                                                    break;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            index++;
                                        }
                                    }
                                }
                                break;

                            case 1: // @proc section - wczytanie sprzętu
                                {
                                    // Format: HW_cost to HW_type
                                    var parts = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                                    if (parts.Length >= 3)
                                    {
                                        int HW_cost = int.Parse(parts[0]);
                                        int to = int.Parse(parts[1]);  // czy to ID? (można pominąć jeśli nie potrzebne)
                                        int HW_type = int.Parse(parts[2]);

                                        Hardware hw = new Hardware(HW_cost, (HardwareType)HW_type, hwIdCounter++);
                                        Hardwares.Add(hw);
                                    }
                                }
                                break;

                            case 2: // @times section - wczytanie macierzy czasów
                                {
                                    var row = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                                                  .Select(int.Parse).ToList();
                                    timesMatrix.Add(row);
                                }
                                break;

                            case 3: // @cost section - wczytanie macierzy kosztów
                                {
                                    var row = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                                                  .Select(int.Parse).ToList();
                                    costsMatrix.Add(row);
                                }
                                break;

                            case 4: // @comm section - wczytanie kanałów komunikacyjnych
                                {
                                    var parts = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                                    if (parts.Length >= 4)
                                    {
                                        int chanNum = int.Parse(parts[0]);
                                        int ComCost = int.Parse(parts[1]);
                                        int BandWidth = int.Parse(parts[2]);

                                        COM c = new COM(BandWidth, ComCost, chanNum);

                                        for (int i = 3; i < parts.Length; i++)
                                        {
                                            if (parts[i] == "1" && i - 3 < Hardwares.Count)
                                            {
                                                c.AddHardware(Hardwares[i - 3]);
                                            }
                                        }
                                        Channels.Add(c);
                                    }
                                }
                                break;
                        }
                    }
                }

                times.SetTimesMatrix(timesMatrix);
                times.SetCostsMatrix(costsMatrix);
                // Podstaw graf i inne struktury, jeśli jest taka potrzeba
                // TaskGraph = loaded (w tym wypadku jest aktualizowany na bieżąco)

                return 1; // sukces
            }
            catch
            {
                return -1; // błąd podczas czytania/parsing
            }
        }

        static void PrintProc(List<Hardware> list, TextWriter writer)
        {
            writer.WriteLine($"@proc {list.Count}");
            foreach (var h in list)
            {
                h.PrintHW(writer);
                writer.WriteLine();
            }
        }

        static void PrintCOMS(List<COM> list, TextWriter writer, int maxHwId)
        {
            writer.WriteLine($"@comm {list.Count}");
            foreach (var c in list)
                c.PrintCOM(writer, maxHwId);
        }
    }
}
