﻿using System.Windows;
using TaskScheduler;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // Tu umieść logikę startową:
        MainWindow window = new MainWindow();
        window.Show();

        // Albo przenieś tu wywołania swojej dotychczasowej logiki.
    }
}
