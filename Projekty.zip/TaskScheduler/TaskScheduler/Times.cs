﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskScheduler
{
    public class Times
    {
        private const int SCALE = 400;
        private Graph tasks;
        private List<Hardware> HWList;
        private List<List<int>> timesMatrix = new();
        private List<List<int>> costMatrix = new();

        public Times(Graph tasks, List<Hardware> HWList)
        {
            this.tasks = tasks;
            this.HWList = HWList;
        }

        public List<List<int>> CountTimes()
        {
            var rand = new Random();
            for (int t = 0; t < tasks.NumberOfVertices; t++)
            {
                var row = new List<int>();
                foreach (var hw in HWList)
                {
                    double adv = 1 + rand.Next(SCALE / 4) / Math.Sqrt(SCALE);
                    int time = (int)(adv * (SCALE / 2.0) * SCALE / (hw.Cost + rand.Next(SCALE / 8)));
                    row.Add(time);
                }
                timesMatrix.Add(row);
            }
            CountCosts();
            return timesMatrix;
        }

        private void CountCosts()
        {
            var rand = new Random();
            foreach (var row in timesMatrix)
            {
                var costRow = new List<int>();
                foreach (var time in row)
                    costRow.Add(SCALE * 8 / time + rand.Next(SCALE / 8));
                costMatrix.Add(costRow);
            }
        }

        public void Show(TextWriter output)
        {
            if (timesMatrix.Count == 0)
                CountTimes();

            output.WriteLine("@times");
            foreach (var row in timesMatrix)
            {
                foreach (var val in row)
                    output.Write($"{val} ");
                output.WriteLine();
            }

            output.WriteLine("@costs");
            foreach (var row in costMatrix)
            {
                foreach (var val in row)
                    output.Write($"{val} ");
                output.WriteLine();
            }
        }
    }
}
