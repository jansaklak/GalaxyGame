﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum HardwareType { HC, PE }

namespace TaskScheduler
{
    public class Hardware
    {
        private static int hwIdCounter = 0;
        public int Id { get; }
        public double Cost { get; }
        public int Restrictions { get; set; }
        public HardwareType Type { get; }

        public Hardware(int adv, HardwareType type)
        {
            Id = hwIdCounter++;
            adv = Math.Min(adv, 10);
            double mn = new Random().Next(400, 1200);
            if (type == HardwareType.PE)
                mn /= 10;
        //Generate random cost
            Cost = adv * mn;
            Type = type;
            Restrictions = 0;
        }

        public Hardware(int adv, HardwareType type, int _cost)
        {
            Id = hwIdCounter++;
            adv = Math.Min(adv, 10);
            double mn = new Random().Next(400, 1200);
            if (type == HardwareType.PE)
                mn /= 10;
            Cost = _cost;
            Type = type;
            Restrictions = 0;
        }

        public void PrintHW(System.IO.TextWriter output)
        {
            output.Write($"{Cost} {Restrictions} {(Type == HardwareType.PE ? 1 : 0)}");
        }
    }
}
