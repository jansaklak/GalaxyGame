﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskScheduler
{
    public class Graph
    {
        public const int SIZE = 100;
        private int[,] matrix = new int[SIZE, SIZE];
        public int NumberOfVertices { get; private set; }

        public Graph() => Clear();

        public void CreateVertices(int count) => NumberOfVertices = count;

        public void AddEdge(int i, int j, int weight = 1)
        {
            if (IsValid(i, j))
                matrix[i, j] = weight;
        }

        public void RemoveEdge(int i, int j)
        {
            if (IsValid(i, j))
                matrix[i, j] = 0;
        }

        public bool CheckEdge(int i, int j) => IsValid(i, j) && matrix[i, j] != 0;

        public int GetWeightEdge(int i, int j) => IsValid(i, j) ? matrix[i, j] : 0;

        public List<int> GetOutNeighbourIndices(int idx)
        {
            var neighbors = new List<int>();
            if (idx < 0 || idx >= SIZE) return neighbors;

            for (int i = 0; i < SIZE; i++)
                if (matrix[idx, i] != 0)
                    neighbors.Add(i);

            return neighbors;
        }

        public void PrintMatrix(int size, TextWriter output)
        {
            size = Math.Min(size, SIZE);
            for (int i = 0; i < size; ++i)
            {
                for (int j = 0; j < size; ++j)
                    output.Write(matrix[i, j] + " ");
                output.WriteLine();
            }
        }

        public void Clear()
        {
            for (int i = 0; i < SIZE; i++)
                for (int j = 0; j < SIZE; j++)
                    matrix[i, j] = 0;
        }

        private bool IsValid(int i, int j) => i >= 0 && i < SIZE && j >= 0 && j < SIZE;
    }
}
