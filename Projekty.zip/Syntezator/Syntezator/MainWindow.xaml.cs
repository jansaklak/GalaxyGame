﻿using System;
using System.IO;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;

namespace Syntezator
{
    public partial class MainWindow : Window
    {
        private SpeechSynthesizer synthesizer = new SpeechSynthesizer();
        private Thread speakingThread;
        private ManualResetEvent pauseEvent = new ManualResetEvent(true);
        private bool isPaused = false;
        private bool isStopped = false;
        private string maleVoice;
        private string femaleVoice;

        public MainWindow()
        {
            InitializeComponent();
            LoadVoices();
            // Set output to default audio device
            synthesizer.SetOutputToDefaultAudioDevice();
        }

        private void LoadVoices()
        {
            string voicesFound = "";
            try
            {
                foreach (var voice in synthesizer.GetInstalledVoices())
                {
                    var info = voice.VoiceInfo;
                    voicesFound += $"{info.Name} ({info.Culture}) - {info.Gender}\n";
                }

                MessageBox.Show("Zainstalowane głosy:\n\n" + voicesFound);

                // Przypisujemy dostępne polskie głosy
                foreach (var voice in synthesizer.GetInstalledVoices())
                {
                    var info = voice.VoiceInfo;
                    if (info.Culture.Name.StartsWith("pl"))
                    {
                        if (info.Gender == VoiceGender.Male && maleVoice == null)
                            maleVoice = info.Name;
                        else if (info.Gender == VoiceGender.Female && femaleVoice == null)
                            femaleVoice = info.Name;
                    }
                }

                // Fallback dla głosów jeśli nie ma polskich
                if (maleVoice == null || femaleVoice == null)
                {
                    // Jeśli nie ma polskich głosów, użyj pierwszego dostępnego
                    var voices = synthesizer.GetInstalledVoices();
                    if (voices.Count > 0)
                    {
                        string defaultVoice = voices[0].VoiceInfo.Name;

                        if (femaleVoice == null)
                        {
                            femaleVoice = defaultVoice;
                            MessageBox.Show($"Nie znaleziono polskiego głosu żeńskiego. Używam: {femaleVoice}");
                        }

                        if (maleVoice == null)
                        {
                            maleVoice = defaultVoice;
                            MessageBox.Show($"Nie znaleziono polskiego głosu męskiego. Używam: {maleVoice}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nie znaleziono żadnych głosów w systemie!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas ładowania głosów: {ex.Message}");
            }
        }

        private void LoadFile_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Pliki tekstowe (*.txt)|*.txt"
            };

            if (dialog.ShowDialog() == true)
            {
                TextBoxContent.Text = File.ReadAllText(dialog.FileName);
            }
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            if (speakingThread != null && speakingThread.IsAlive)
                return;

            isStopped = false;
            isPaused = false;
            pauseEvent.Set();

            try
            {
                speakingThread = new Thread(() => SpeakText(TextBoxContent.Text));
                speakingThread.IsBackground = true;
                speakingThread.Start();

                Dispatcher.Invoke(() => StatusLabel.Text = "Rozpoczęto odtwarzanie...");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas uruchamiania: {ex.Message}");
            }
        }

        private void PauseResume_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (isPaused)
                {
                    synthesizer.Resume();
                    pauseEvent.Set();
                    Dispatcher.Invoke(() => StatusLabel.Text = "Wznawianie...");
                }
                else
                {
                    synthesizer.Pause();
                    pauseEvent.Reset();
                    Dispatcher.Invoke(() => StatusLabel.Text = "Pauza...");
                }

                isPaused = !isPaused;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas pauzy/wznowienia: {ex.Message}");
            }
        }

        private void Stop_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                isStopped = true;
                synthesizer.SpeakAsyncCancelAll();
                pauseEvent.Set(); // w razie pauzy
                Dispatcher.Invoke(() => StatusLabel.Text = "Zatrzymano.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas zatrzymywania: {ex.Message}");
            }
        }

        private void SpeakText(string text)
        {
            try
            {
                // Sprawdź czy tekst jest pusty
                if (string.IsNullOrWhiteSpace(text))
                {
                    Dispatcher.Invoke(() =>
                    {
                        StatusLabel.Text = "Brak tekstu do odczytania";
                        MessageBox.Show("Proszę wpisać lub wczytać tekst do odczytania.");
                    });
                    return;
                }

                var matches = Regex.Matches(text, @"<voice=(male|female)>(.*?)</voice>", RegexOptions.Singleline | RegexOptions.IgnoreCase);

                if (matches.Count == 0)
                {
                    // Jeśli nie ma znaczników, przeczytaj cały tekst domyślnym głosem
                    Dispatcher.Invoke(() =>
                    {
                        StatusLabel.Text = "Brak znaczników <voice=...>, używam domyślnego głosu";
                        MessageBox.Show("Nie znaleziono znaczników <voice=male> lub <voice=female>. " +
                                       "Tekst zostanie odczytany domyślnym głosem.");
                    });

                    synthesizer.SelectVoice(femaleVoice);
                    synthesizer.Speak(text);

                    Dispatcher.Invoke(() => StatusLabel.Text = "Zakończono odczytywanie.");
                    return;
                }

                foreach (Match match in matches)
                {
                    if (isStopped)
                        break;

                    string gender = match.Groups[1].Value.ToLower();
                    string content = match.Groups[2].Value.Trim();

                    if (string.IsNullOrWhiteSpace(content))
                        continue;

                    string voiceName = gender == "male" ? maleVoice : femaleVoice;

                    Dispatcher.Invoke(() => StatusLabel.Text = $"Mówi: {gender} ({voiceName})");

                    pauseEvent.WaitOne(); // czekamy jeśli wstrzymane

                    try
                    {
                        synthesizer.SelectVoice(voiceName);
                        synthesizer.Speak(content); // Używamy metody synchronicznej Speak zamiast SpeakAsync
                    }
                    catch (Exception ex)
                    {
                        Dispatcher.Invoke(() => MessageBox.Show($"Błąd podczas odtwarzania głosu '{voiceName}': {ex.Message}"));
                        break;
                    }

                    if (isStopped) break;
                }

                Dispatcher.Invoke(() => StatusLabel.Text = "Zakończono.");
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    StatusLabel.Text = $"Błąd: {ex.Message}";
                    MessageBox.Show($"Błąd podczas odtwarzania: {ex.Message}");
                });
            }
        }
    }
}