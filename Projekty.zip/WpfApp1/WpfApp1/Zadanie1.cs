﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class Zadanie1

    {
        
        public Zadanie1() {
            
        }
        

        public float Potega(int a, int b, int c)
        {
            if (c <= 0)
            {
                throw new CustomException("trzeci argument jest mniejszy od 0");
            }
            if (b < 0)
            {
                throw new CustomException("wykladnik mniejszy od 0");
            }
            return (float)Math.Pow(a, b);
        }

        public List<int> ZapiszWTablicy(List<int> tab, int a)
        {
            List<int> mnozTab = new List<int>();
            foreach (var item in tab)
            {
                mnozTab.Add(item * 2);
            }
            return mnozTab;
        }

        public double PoleKola(float r)
        {
            if (r <= 0)
            {
                throw new CustomException("promien musi byc wiekszy od 0");
            }
            return Math.PI * r * r;
        }

        public string SumaCyfr(int liczba)
        {
            if (liczba < 100 || liczba > 999)
            {
                throw new CustomException("podana liczba nie jest trzycyfrowa");
            }
            int suma = (liczba / 100) + ((liczba / 10) % 10) + (liczba % 10);
            string odp = (suma % 3 == 0 ? "liczba podzielna przez 3" : "liczba nie jest podzielna przez 3");
            return odp;
        }
    }

    class CustomException : Exception
    {
        public CustomException(string message) : base(message) { }
    }
}
